.getPCGPemail <- function () {
if (!exists(".PCGPemail")){
.PCGPemail <<- readline("Please enter your PCGP registered email address: \n")
}
}




